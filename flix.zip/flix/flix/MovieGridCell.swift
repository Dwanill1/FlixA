//
//  MovieGridCell.swift
//  flix
//
//  Created by Dhwanil Mehta on 27/09/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
